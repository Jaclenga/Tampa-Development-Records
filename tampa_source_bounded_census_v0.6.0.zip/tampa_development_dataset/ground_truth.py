#!/usr/bin/env python3
"""Build conservative ground-truth scaffolding from normalized Tampa records.

This module never treats a permit, footprint, assessment year, or capital
closeout label as proof of completed physical work.  It creates the relational
tables needed to add Accela inspections/COs and independent review later.
"""

from __future__ import annotations

import csv
import hashlib
import re
from collections import Counter, defaultdict
from pathlib import Path


TRUTH_VALUES = {"yes", "no", "unknown", "not_applicable"}
EVENT_TYPES = {
    "permit_applied", "permit_issued", "inspection_passed", "inspection_failed",
    "final_inspection_passed", "certificate_of_occupancy_issued", "construction_started",
    "substantial_completion", "project_closeout", "permit_expired", "permit_cancelled",
    "planning_application",
}

FIELD_DEFINITIONS = {
    "physical_work_started": "Whether qualifying evidence establishes that physical work started.",
    "physical_work_completed": "Whether qualifying evidence establishes that physical work completed.",
    "certificate_of_occupancy_issued": "Whether an official certificate-of-occupancy event is present.",
    "final_inspection_passed": "Whether an official passed-final-inspection event is present.",
    "project_cancelled": "Whether an official cancelled, withdrawn, denied, or expired status is present.",
    "completion_date": "Date of the qualifying completion event, when one exists.",
    "verification_grade": "Highest evidence-hierarchy grade supported by current evidence.",
    "verification_basis": "Machine-readable explanation for the evidence grade.",
    "verification_source": "Source endpoint or evidence record used for the truth assessment.",
    "verification_date": "Date on which the cited evidence was assessed or retrieved.",
    "verification_method": "Method used to turn evidence into the truth-status fields.",
    "building_year_supporting_evidence": "Whether a compatible building-year inference exists as non-dispositive support.",
    "human_review_status": "Status of required human ground-truth review.",
    "master_project_id": "Stable provisional identifier for a real-world master-project entity.",
    "activity_count": "Number of activities currently assigned to the master project.",
    "entity_resolution_status": "Whether master-project grouping is provisional or reviewed.",
    "relationship_type": "Semantic relationship between an activity and its master project.",
    "candidate_id": "Stable identifier for a proposed cross-activity project match.",
    "activity_id_a": "First activity in a candidate master-project pair.",
    "activity_id_b": "Second activity in a candidate master-project pair.",
    "candidate_reasons": "Semicolon-delimited deterministic signals proposing a match.",
    "candidate_confidence": "Rule-based priority tier for candidate review.",
    "merge_applied": "Whether the candidate pair was actually merged.",
    "event_id": "Stable identifier for one dated or undated development event.",
    "permit_id": "Native permit or record identifier associated with the event.",
    "event_type": "Normalized development-event category.",
    "event_date": "Date reported for the event.",
    "event_result": "Reported result or conservative interpretation of the event.",
    "source_system": "Source layer or system contributing the event.",
    "retrieved_at": "UTC time at which the event source was retrieved.",
    "amount_id": "Stable identifier for one reported monetary amount.",
    "amount_usd": "Reported nominal-dollar amount; not a harmonized investment total.",
    "amount_type": "Meaning of the reported amount.",
    "price_year": "Nominal price year inferred from the associated record date, when available.",
    "public_or_private": "Financing/owner sector supported by the source.",
    "is_estimate": "Whether the amount is explicitly an estimate.",
    "is_final": "Whether the source establishes that the amount is final.",
    "building_match_audit_id": "Stable identifier for one building-match audit row.",
    "normalized_address_agreement": "Whether normalized activity and footprint addresses exactly agree.",
    "multiple_matched_buildings": "Whether the activity has more than one matched footprint.",
    "geometry_check": "Spatial rule used by the building match.",
    "historical_imagery_checked": "Whether dated historical imagery was reviewed.",
    "new_footprint_vs_addition": "Reviewer judgment distinguishing a new footprint from an addition.",
    "human_match_correct": "Human judgment of building-match correctness.",
    "evidence_url": "Public URL supporting a review judgment.",
    "exact_address_agreement_count": "Rows in the stratum with exact normalized-address agreement.",
    "multiple_building_activity_count": "Rows in the stratum attached to a multi-match activity.",
    "human_reviewed_count": "Rows in the stratum with a completed human match judgment.",
    "empirical_precision": "Human-reviewed correct matches divided by reviewed matches.",
    "reviewer_2_id": "Identifier for an independent second reviewer.",
    "reviewer_2_one_activity_one_development": "Second-reviewer judgment of activity-to-development uniqueness.",
    "reviewer_2_building_match_correct": "Second-reviewer judgment of building-match correctness.",
    "reviewer_2_completion_classification": "Second-reviewer judgment of completion classification.",
    "reviewer_2_notes": "Second reviewer rationale and evidence notes.",
    "reviewer_2_reviewed_at_utc": "UTC timestamp of the independent second review.",
}


def metadata_for(field: str):
    if field not in FIELD_DEFINITIONS:
        return None
    truth = field in {"physical_work_started", "physical_work_completed", "certificate_of_occupancy_issued", "final_inspection_passed", "project_cancelled"}
    reviewer = field.startswith("reviewer_2") or field in {"human_match_correct", "historical_imagery_checked", "new_footprint_vs_addition"}
    valid = "yes; no; unknown; not_applicable" if truth else "Protocol- or source-defined."
    if field == "verification_grade": valid = "A1; A2; A3; B1; B2; C; D; P; X; U"
    if field == "event_type": valid = "; ".join(sorted(EVENT_TYPES))
    if field == "merge_applied": valid = "yes; no"
    null = "Blank means unavailable or not yet reviewed; unknown is represented explicitly where required."
    return (FIELD_DEFINITIONS[field], "categorical text" if truth or reviewer else "text", "", null,
            "reviewer-entered" if reviewer else "derived/source evidence", "See GROUND_TRUTH_METHODOLOGY.md and ground_truth.py.", valid,
            "Do not interpret absence or unknown as no; this field is not proof beyond its cited evidence.")


def token(value: str, length: int = 16) -> str:
    return hashlib.sha1(value.encode("utf-8")).hexdigest()[:length]


def clean(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def normalize_address(value: object) -> str:
    text = re.sub(r"[^A-Z0-9 ]", " ", clean(value).upper())
    replacements = {"STREET": "ST", "AVENUE": "AVE", "ROAD": "RD", "BOULEVARD": "BLVD", "DRIVE": "DR"}
    return " ".join(replacements.get(part, part) for part in text.split())


def write_csv(path: Path, rows: list[dict], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def evidence_for(activity: dict) -> tuple[str, str, str, str]:
    """Return grade, basis, started, cancelled without inventing completion."""
    status = clean(activity.get("status")).lower()
    activity_class = clean(activity.get("activity_class"))
    stage = clean(activity.get("activity_stage"))
    if any(word in status for word in ("cancel", "withdraw", "denied", "expired")):
        return "X", "inactive_official_status", "unknown", "yes"
    if "construction" in status or stage == "construction_or_inspection":
        return "C", "official_construction_or_inspection_status", "yes", "unknown"
    if activity_class in {"planning_application", "historic_preservation_application"}:
        return "P", "planning_application_only", "not_applicable", "unknown"
    if stage == "permit_or_funding_approved" or "issued" in status or "approved" in status:
        return "D", "permit_or_funding_approved_only", "unknown", "unknown"
    return "U", "insufficient_completion_evidence", "unknown", "unknown"


def build_truth(activities: list[dict]) -> list[dict]:
    rows = []
    for a in activities:
        grade, basis, started, cancelled = evidence_for(a)
        planning = a.get("activity_class") in {"planning_application", "historic_preservation_application"}
        na = "not_applicable" if planning else "unknown"
        rows.append({
            "activity_id": a["activity_id"],
            "physical_work_started": started,
            "physical_work_completed": na,
            "certificate_of_occupancy_issued": na,
            "final_inspection_passed": na,
            "project_cancelled": cancelled,
            "completion_date": "",
            "verification_grade": grade,
            "verification_basis": basis,
            "verification_source": clean(a.get("source_endpoint")),
            "verification_date": clean(a.get("retrieved_at_utc"))[:10],
            "verification_method": "deterministic_official_status_classification",
            "building_year_supporting_evidence": "yes" if str(a.get("realization_basis", "")).startswith("permit_plus_current_footprint_year_built") else "no",
            "human_review_status": "pending",
        })
    return rows


def build_projects(activities: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    projects, links = [], []
    for a in activities:
        mid = f"mp-{token(a['activity_id'])}"
        projects.append({
            "master_project_id": mid, "project_name": clean(a.get("project_name")),
            "address": clean(a.get("address")), "activity_count": "1",
            "entity_resolution_status": "provisional_singleton",
        })
        links.append({
            "master_project_id": mid, "activity_id": a["activity_id"],
            "relationship_type": "provisional_singleton",
            "match_method": "no_safe_cross_activity_merge",
            "match_confidence": "unknown", "review_status": "needs_review",
        })

    # Candidate pairs are proposals only; they never alter master_project_id.
    by_address: dict[str, list[dict]] = defaultdict(list)
    by_folio: dict[str, list[dict]] = defaultdict(list)
    for a in activities:
        address = normalize_address(a.get("address"))
        if address:
            by_address[address].append(a)
        for folio in clean(a.get("matched_folios")).split(";"):
            if folio:
                by_folio[folio].append(a)
    proposed: dict[tuple[str, str], set[str]] = defaultdict(set)
    for label, groups in (("exact_normalized_address", by_address), ("shared_city_building_folio", by_folio)):
        for rows in groups.values():
            if 1 < len(rows) <= 25:
                ids = sorted({r["activity_id"] for r in rows})
                for i, left in enumerate(ids):
                    for right in ids[i + 1:]:
                        proposed[(left, right)].add(label)
    candidates = []
    for (left, right), reasons in sorted(proposed.items()):
        candidates.append({
            "candidate_id": f"cand-{token(left + '|' + right)}",
            "activity_id_a": left, "activity_id_b": right,
            "candidate_reasons": ";".join(sorted(reasons)),
            "candidate_confidence": "medium" if len(reasons) > 1 else "low",
            "review_status": "pending_human_review", "merge_applied": "no",
        })
    return projects, links, candidates


def build_events(activities: list[dict], links: list[dict]) -> list[dict]:
    master = {r["activity_id"]: r["master_project_id"] for r in links}
    rows = []
    for a in activities:
        aid, status = a["activity_id"], clean(a.get("status")).lower()
        permit_id = clean(a.get("source_record_id"))
        specs = []
        opened = clean(a.get("application_or_opened_date")) or clean(a.get("record_created_date"))
        if opened:
            specs.append(("planning_application" if "planning" in clean(a.get("activity_class")) else "permit_applied", opened, "recorded"))
        if "issued" in status or "approved" in status:
            specs.append(("permit_issued", clean(a.get("status_date")) or opened, "recorded"))
        if "construction" in status or clean(a.get("activity_stage")) == "construction_or_inspection":
            specs.append(("construction_started", clean(a.get("status_date")), "status_indicates_in_progress"))
        if "closeout" in status:
            specs.append(("project_closeout", clean(a.get("status_date")), "administrative_closeout_only"))
        if "expired" in status:
            specs.append(("permit_expired", clean(a.get("status_date")), "recorded"))
        if any(x in status for x in ("cancel", "withdraw", "denied")):
            specs.append(("permit_cancelled", clean(a.get("status_date")), "recorded"))
        for event_type, event_date, result in specs:
            seed = "|".join((aid, event_type, event_date, result))
            rows.append({
                "event_id": f"evt-{token(seed)}", "master_project_id": master[aid],
                "permit_id": permit_id, "event_type": event_type, "event_date": event_date,
                "event_result": result, "source_system": clean(a.get("source_memberships")),
                "source_record_id": permit_id, "source_url": clean(a.get("source_url")) or clean(a.get("source_endpoint")),
                "retrieved_at": clean(a.get("retrieved_at_utc")),
            })
    return rows


def build_amounts(activities: list[dict]) -> list[dict]:
    rows = []
    for a in activities:
        for field, kind, estimate in (
            ("estimated_cost_usd", "city_capital_project_estimated_cost", "yes"),
            ("actual_cost_usd", "city_capital_project_reported_actual_cost", "no"),
        ):
            raw = clean(a.get(field))
            try:
                amount = float(raw)
            except ValueError:
                continue
            if amount <= 0:
                continue
            date = clean(a.get("status_date")) or clean(a.get("record_created_date"))
            rows.append({
                "amount_id": f"amt-{token(a['activity_id'] + '|' + field)}", "activity_id": a["activity_id"],
                "amount_usd": f"{amount:.2f}", "amount_type": kind,
                "price_year": date[:4] if re.match(r"^20\d{2}", date) else "",
                "public_or_private": "public", "source": clean(a.get("source_endpoint")),
                "is_estimate": estimate, "is_final": "unknown",
            })
    return rows


def build_match_audit(activities: list[dict], matches: list[dict]) -> tuple[list[dict], list[dict]]:
    by_id = {a["activity_id"]: a for a in activities}
    counts = Counter(m["activity_id"] for m in matches)
    audit = []
    for m in matches:
        a = by_id[m["activity_id"]]
        address_agree = "yes" if normalize_address(a.get("address")) and normalize_address(a.get("address")) == normalize_address(m.get("building_address")) else "no"
        audit.append({
            "building_match_audit_id": f"bma-{token(m['activity_id'] + '|' + clean(m.get('location_id')) + '|' + clean(m.get('building_object_id')))}",
            "activity_id": m["activity_id"], "location_id": clean(m.get("location_id")),
            "building_object_id": clean(m.get("building_object_id")), "match_method": clean(m.get("match_method")),
            "match_confidence": clean(m.get("match_confidence")), "match_distance_m": clean(m.get("match_distance_m")),
            "normalized_address_agreement": address_agree,
            "multiple_matched_buildings": "yes" if counts[m["activity_id"]] > 1 else "no",
            "geometry_check": "point_in_footprint" if m.get("match_method") == "point_in_building_footprint" else "proximity_or_address_rule",
            "historical_imagery_checked": "unknown", "new_footprint_vs_addition": "unknown",
            "human_match_correct": "unknown", "reviewer_id": "", "reviewed_at_utc": "", "evidence_url": "", "review_notes": "",
        })
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in audit:
        grouped[(row["match_method"], row["match_confidence"])].append(row)
    diagnostics = []
    for (method, confidence), rows in sorted(grouped.items()):
        diagnostics.append({
            "match_method": method, "match_confidence": confidence, "match_count": len(rows),
            "exact_address_agreement_count": sum(r["normalized_address_agreement"] == "yes" for r in rows),
            "multiple_building_activity_count": sum(r["multiple_matched_buildings"] == "yes" for r in rows),
            "human_reviewed_count": "0", "empirical_precision": "",
        })
    return audit, diagnostics


def build_review2(sample: list[dict], target: int = 30) -> list[dict]:
    chosen = sorted(sample, key=lambda r: token("second-review|" + r["activity_id"], 40))[:target]
    return [{
        "audit_sample_id": r["audit_sample_id"], "activity_id": r["activity_id"],
        "reviewer_2_id": "", "reviewer_2_one_activity_one_development": "",
        "reviewer_2_building_match_correct": "", "reviewer_2_completion_classification": "",
        "reviewer_2_notes": "", "reviewer_2_reviewed_at_utc": "",
    } for r in chosen]


def build_all(processed: Path, activities: list[dict], matches: list[dict], sample: list[dict]) -> dict[str, int]:
    truth = build_truth(activities)
    projects, links, candidates = build_projects(activities)
    events = build_events(activities, links)
    amounts = build_amounts(activities)
    audit, diagnostics = build_match_audit(activities, matches)
    review2 = build_review2(sample)
    tables = {
        "activity_truth_status.csv": (truth, list(truth[0])),
        "master_projects.csv": (projects, list(projects[0])),
        "master_project_activity_links.csv": (links, list(links[0])),
        "master_project_candidates.csv": (candidates, ["candidate_id", "activity_id_a", "activity_id_b", "candidate_reasons", "candidate_confidence", "review_status", "merge_applied"]),
        "development_events.csv": (events, ["event_id", "master_project_id", "permit_id", "event_type", "event_date", "event_result", "source_system", "source_record_id", "source_url", "retrieved_at"]),
        "investment_amounts.csv": (amounts, ["amount_id", "activity_id", "amount_usd", "amount_type", "price_year", "public_or_private", "source", "is_estimate", "is_final"]),
        "building_match_audit.csv": (audit, list(audit[0]) if audit else []),
        "building_match_diagnostics.csv": (diagnostics, list(diagnostics[0]) if diagnostics else []),
        "manual_validation_second_review.csv": (review2, list(review2[0])),
    }
    for name, (rows, columns) in tables.items():
        write_csv(processed / name, rows, columns)
    return {name: len(rows) for name, (rows, _) in tables.items()}
